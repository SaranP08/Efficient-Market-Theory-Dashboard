import yfinance as yf
import numpy as np
from scipy.stats import norm
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk  
from tkcalendar import DateEntry  
import ctypes
from PIL import Image, ImageTk

def fetch_stock_data(ticker, start_date, end_date):
    stock_data = yf.download(ticker, start=start_date, end=end_date)
    return stock_data

def runs_test_analysis(stock_data):
    closing_prices = stock_data['Adj Close']
    signs = np.sign(closing_prices.diff().dropna())
    n1 = (signs == 1).sum()
    n2 = (signs == -1).sum()
    R = signs.diff().fillna(0).abs().sum() + 1
    ER = (2 * n1 * n2) / (n1 + n2) + 1 + 0.5
    sigma_R = np.sqrt((2 * n1 * n2 * (2 * n1 * n2 - n1 - n2)) / ((n1 + n2)**2 * (n1 + n2 - 1)))
    Z = (R - ER) / sigma_R
    critical_Z = norm.ppf(0.975)
    lb = ER - Z * sigma_R
    ub = ER + Z * sigma_R

    return ER, sigma_R, lb, ub, Z, critical_Z

def display_results(ticker, start_date, end_date):
    try:
        stock_data = fetch_stock_data(ticker, start_date, end_date)
        ER, sigma_R, lb, ub, Z, critical_Z = runs_test_analysis(stock_data)

        results = f"""
        Runs Test Analysis for {ticker}:
        
        Mean (ER): {ER}
        Standard Deviation (σR): {sigma_R}
        Lower Bound: {lb}
        Upper Bound: {ub}
        Z value: {Z}
        Critical Z value: {critical_Z}
        """
        if Z > critical_Z:
            results += "\nThe price movements are affected by their past prices."
        else:
            results += "\nNo significant evidence to conclude that the price movements are affected by their past prices."

        if lb <= Z <= ub:
            results += "\nRelation: Weak Relation"
        else:
            results += "\nRelation: Semi or Strong Relation"

        result_text.delete("1.0", tk.END)
        result_text.insert(tk.END, results)
    except Exception as e:
        messagebox.showerror("Error", str(e))

def open_analysis_window():
    home_window.withdraw()
    analysis_window.deiconify()

def return_home():
    analysis_window.withdraw()
    home_window.deiconify()

def on_analysis_window_close():
    return_home()

def on_analyze():
    ticker = ticker_entry.get()
    start_date = start_date_entry.get_date()
    end_date = end_date_entry.get_date()
    display_results(ticker, start_date, end_date)

############################
user32 = ctypes.windll.user32
screen_width, screen_height = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

home_window = tk.Tk()
home_window.title("Efficient Market theory Analysis Home")
home_window.geometry(f"{screen_width}x{screen_height}")

image_path = "D:/Wall/1920.jpg"  
bg_image = Image.open(image_path)

bg_image = bg_image.resize((screen_width, screen_height))

bg_photo = ImageTk.PhotoImage(bg_image)

canvas = tk.Canvas(home_window, width=screen_width, height=screen_height)
canvas.pack(fill="both", expand=True)
canvas.create_image(0, 0, image=bg_photo, anchor="nw")

canvas.create_text(screen_width // 2, screen_height // 4, text="Welcome to Efficient Market theory Analysis", font=("Garamond", 30, "bold"), fill="white")

analyze_button = tk.Button(home_window, text="Select Stock and Analyze", command=open_analysis_window, bg="blue", fg="white", font=("Garamond", 20, "bold"))
canvas.create_window(screen_width // 2, screen_height * 3 // 4, window=analyze_button)

analysis_window = tk.Toplevel(home_window)
analysis_window.title("Stock Runs Test Analysis")
analysis_window.geometry(f"{screen_width}x{screen_height}")  
analysis_window.withdraw()  

analysis_bg_image = Image.open("D:/Wall/1920.jpg")
analysis_bg_image = analysis_bg_image.resize((screen_width, screen_height))
analysis_bg_photo = ImageTk.PhotoImage(analysis_bg_image)

analysis_canvas = tk.Canvas(analysis_window, width=screen_width, height=screen_height)
analysis_canvas.pack(fill="both", expand=True)
analysis_canvas.create_image(0, 0, image=analysis_bg_photo, anchor="nw")

analysis_window.protocol("WM_DELETE_WINDOW", return_home)

analysis_window.grid_rowconfigure(0, weight=1)
analysis_window.grid_rowconfigure(7, weight=1)
analysis_window.grid_columnconfigure(0, weight=1)
analysis_window.grid_columnconfigure(3, weight=1)

tk.Label(analysis_canvas, text="Stock Ticker:", font=("Garamond", 18, "bold")).pack(padx=10, pady=10)

ticker_entry = ttk.Combobox(analysis_canvas, values=['AAPL', 'GOOGL',
'MSFT', 'AMZN', 'TSLA', 'NVDA'], font=("Garamond", 14))
ticker_entry.pack(padx=10, pady=10) ticker_entry.set('AAPL')

tk.Label(analysis_canvas, text="Start Date:", font=("Garamond", 18, "bold")).pack(padx=10, pady=10)
start_date_entry = DateEntry(analysis_canvas, date_pattern='yyyy-mm-dd', font=("Garamond", 14))
start_date_entry.pack(padx=10, pady=10)

tk.Label(analysis_canvas, text="End Date:", font=("Garamond", 18, "bold")).pack(padx=10, pady=10)
end_date_entry = DateEntry(analysis_canvas, date_pattern='yyyy-mm-dd', font=("Garamond", 14))
end_date_entry.pack(padx=10, pady=10)

analyze_button = tk.Button(analysis_canvas, text="Analyze", command=on_analyze, bg="blue", fg="white", font=("Garamond", 18, "bold"))
analyze_button.pack(padx=10, pady=10)

result_text = tk.Text(analysis_canvas, wrap=tk.WORD, width=70, height=15, font=("Garamond", 14), bd=2, relief="groove")
result_text.pack(padx=10, pady=10)

back_button = tk.Button(analysis_canvas, text="Back", command=return_home, bg="grey", fg="white", font=("Garamond", 18, "bold"))
back_button.pack(padx=10, pady=10)

home_window.mainloop()
